class Tag < ApplicationRecord
    belongs_to :todo_item
end
